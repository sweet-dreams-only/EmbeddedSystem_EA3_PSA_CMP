/** @file sys_main.c 
*   @brief Application main file
*   @date 04.October.2011
*   @version 1.02.000
*
*   This file contains an empty main function,
*   which can be used for the application.
*/

/* (c) Texas Instruments 2009-2011, All rights reserved. */

/* USER CODE BEGIN (0) */
/* USER CODE END */

/* Include Files */

#include "sys_common.h"
#include "system.h"
#include "nhet.h"
#include "rti.h"

/* USER CODE BEGIN (1) */
/* USER CODE END */


/** @fn void main(void)
*   @brief Application main function
*   @note This function is empty by default.
*
*   This function is called after startup.
*   The user can use this function to implement the application.
*/

/* USER CODE BEGIN (2) */
/* USER CODE END */

void main(void)
{
/* USER CODE BEGIN (3) */

	unsigned int i = 0;

	/* Configure N2HET1[0] as output */
    gioSetDirection(nhetPORT1, 0x1);


    while(1)
    {
        gioSetPort(nhetPORT1, gioGetPort(nhetPORT1) ^ 0x00000001);
    	for (i = 0; i < 200000; i++);
    }

/* USER CODE END */
}


/* USER CODE BEGIN (4) */
/* USER CODE END */
